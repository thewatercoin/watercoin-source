Building WaterCoin
================

See doc/build-*.md for instructions on building the various
elements of the WaterCoin Core reference implementation of WaterCoin.
